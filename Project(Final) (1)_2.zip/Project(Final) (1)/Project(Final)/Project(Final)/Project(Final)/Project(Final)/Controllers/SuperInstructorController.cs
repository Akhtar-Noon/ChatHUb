﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Project_Final_.Models;
using Project_Final_.Data;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;

namespace Project_Final_.Controllers
{
    public class SuperInstructorController : Controller
    {
        private readonly ApplicationContext context;
        

        public SuperInstructorController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(SuperInstructor model)
        {
            if (ModelState.IsValid)
            {
                var data = context.SuperInstructors.Where(e => e.username == model.username).SingleOrDefault();
                if (data != null)
                {
                    bool isvalid = (data.username == model.username && data.password == model.password);
                    if (isvalid)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.username) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("username", model.username);
                        return RedirectToAction("Index", "SuperInstructor");
                    }
                    else
                    {
                        TempData["ErrorPassword"] = "Password Invalid!";
                        return View(model);
                    }
                }
                else
                {
                    TempData["ErrorUsername"] = "Username Invalid";
                    return View(model);
                }
            }
            else
            {
                return View(model);

            }
        }
    }
}