﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project_Final_.Data;
using Project_Final_.Models;

namespace Project_Final_.Controllers
{
    public class InstructorController : Controller
    {

        private readonly ApplicationContext context;

        public InstructorController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            var result = context.Instructors.ToList();
            return View(result);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Instructor model)
        {
            if (ModelState.IsValid)
            {
                var ins = new Instructor()
                {
                    fullname = model.fullname,
                    username = model.username,
                    email = model.email,
                    password = model.password
                };
                context.Instructors.Add(ins);
                context.SaveChanges();
                return RedirectToAction("Index");

            }
            else
            {
                TempData["Error"] = "Model Field Can't Submit!";
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Instructor model)
        {
            if (ModelState.IsValid)
            {
                var data=context.Instructors.Where(e=>e.username==model.username).SingleOrDefault();
                if (data!=null)
                {
                    bool isvalid= (data.username==model.username && data.password==model.password);
                    if(isvalid)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.username) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal= new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,principal);
                        HttpContext.Session.SetString("username", model.username);
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        TempData["ErrorPassword"] = "Password Invalid!";
                        return View(model);
                    }
                }
                else
                {
                    TempData["ErrorUsername"] = "Username Invalid";
                    return View(model);
                }
            }
            else
            {
                return View(model);

            }
        }
        
        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Instructor");
        }



       



    }
}