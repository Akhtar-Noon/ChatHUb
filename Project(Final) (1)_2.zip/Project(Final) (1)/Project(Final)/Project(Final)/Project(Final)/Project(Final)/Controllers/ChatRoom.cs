﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project_Final_.Data;
using System.Linq;

namespace Project_Final_.Controllers
{
    public class ChatRoomController : Controller
    {
        private readonly ApplicationContext db;

        public ChatRoomController(ApplicationContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            var comments=db.Comments.Include(x=>x.Replies).ToList();
            return View(comments);
        }
    }
}
