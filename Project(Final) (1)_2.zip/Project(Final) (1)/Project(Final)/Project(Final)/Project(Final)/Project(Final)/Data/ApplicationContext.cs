﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Project_Final_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Final_.Data
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options) { }
        public DbSet<Instructor> Instructors { get; set; }
        public DbSet<Candidate> Candidates { get; set; }
        public DbSet<SuperInstructor> SuperInstructors { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<Reply> Replies { get; set; }



        //protected override void OnModelCreating(ModelBuilder builder)
        //{
        //    base.OnModelCreating (builder);
        //    builder.Entity<Message>()
        //        .HasOne<AppUser>(a => a.sender)
        //        .WithMany(d => d.Messages)
        //        .HasForeignKey(d => d.userid);
        //}
        //public DbSet<Message> Messages { get; set; }

    }
}
