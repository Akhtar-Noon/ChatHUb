﻿using System.Collections.Generic;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project_Final_.Models
{
    public class Comment
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string text { get; set; }
        [ScaffoldColumn(false)]
        public DateTime? CreatedOn { get; set; }
        public int Instructorid { get; set; }
        [ForeignKey("Instructorid")]
        public virtual Instructor Instructor { get; set; }
        public ICollection<Reply> Replies { get; set; }
    }
}
