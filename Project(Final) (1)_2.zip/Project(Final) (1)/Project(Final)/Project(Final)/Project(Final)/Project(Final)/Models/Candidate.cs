﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Final_.Models
{
    public class Candidate
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string fullname { get; set; }

        public string username { get; set; }

        public string email { get; set; }

        public string password { get; set; }
    }
}
