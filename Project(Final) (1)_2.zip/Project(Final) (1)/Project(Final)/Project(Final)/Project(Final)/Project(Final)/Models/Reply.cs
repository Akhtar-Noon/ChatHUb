﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Project_Final_.Models
{
    public class Reply
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Text { get; set; }
        public int CommentId { get; set; }
        [ScaffoldColumn(false)]
        public DateTime? CreatedOn { get; set; }

        public int Instructorid { get; set; }
        [ForeignKey("Instructorid")]

        public virtual Instructor Instructor { get; set; }
        [ForeignKey("CommentId")]
        public virtual Comment Comment { get; set; }
    }
}
